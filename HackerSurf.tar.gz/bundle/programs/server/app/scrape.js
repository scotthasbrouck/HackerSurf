(function(){Scrapes = new Mongo.Collection("scrapes");

})();
