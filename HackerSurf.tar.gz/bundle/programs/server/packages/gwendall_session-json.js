(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gwendall:session-json'] = {};

})();

//# sourceMappingURL=gwendall_session-json.js.map
